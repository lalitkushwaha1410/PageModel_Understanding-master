package com.moreunderstanding.pageobject;

public class Registration_Number 
{
	String reg_no;

}
