package com.moreunderstanding.pageobject;

public class Car 
{
	String carModel;
	Registration_Number  rno;

}
