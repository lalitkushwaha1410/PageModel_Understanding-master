package com.test;

public class House extends Building
{
	Bathroom b=new Bathroom();
	
	public House(Bathroom b)
	{
		this.b=b;
	}
	

}
