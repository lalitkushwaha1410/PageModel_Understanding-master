package com.test;

public class Bathroom
{
	
	public int mirrors;
	
	public void setMirrors(int m)
	{
		mirrors= m;
	}
	
	
	public int getMirrors()
	{
		return mirrors;
	}

}
