package com.test;

public class Building 
{
	
	public void color()
	{
		System.out.println("Blue");
	}

}
